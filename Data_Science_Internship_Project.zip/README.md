
# Data Science Internship Project

## Project Overview
This project demonstrates Exploratory Data Analysis (EDA), data preprocessing,
machine learning model building, and evaluation using the Titanic dataset.

## Tools Used
- Python
- Pandas
- NumPy
- Matplotlib
- Scikit-learn

## Project Structure
- data/ → dataset folder
- notebook.ipynb → Jupyter notebook
- main.py → ML pipeline script
- requirements.txt → dependencies

## How to Run
1. Install requirements:
   pip install -r requirements.txt

2. Run main script:
   python main.py
